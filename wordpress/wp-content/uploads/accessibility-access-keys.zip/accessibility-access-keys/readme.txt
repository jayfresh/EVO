=== Accessibility Access Keys ===
Contributors: Cory Bohon, BrailleSC.org
Tags: Accessibility, Access Keys, impaired, end users
Requires at least: 2.0.2
Tested up to: 3.1
Stable tag: trunk

Lets a WordPress administrator create an maintain site-wide access keys for easy navigation. 

== Description == 
Accessibility Access Keys lets WordPress administrators easily create and maintain site-wide access keys for easy navigation. 

For more help and documentation, visit the plugin page on AccessibleFutures.org: http://accessiblefutures.org/plugins.html

== Installation == 
1. Unpack and upload folder to the /wp-content/plugins directory of your WordPress installation. 
2. Activate the plugin through the 'Plugins' menu in WordPress
3. After activating, configure the plugin by clicking 'Configure Access Keys' under the 'Settings' menu in WordPress